var request = require('request');
var config = require('./config.json');
var f = module.exports = {};

f.summarize = function (data) { 
	// code goes here
	//return
};